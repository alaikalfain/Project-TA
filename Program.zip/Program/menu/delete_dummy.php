<?php

require '..\function.php';

$id = $_GET["id"];

if(delete_dummy($id) > 0){
    echo "
        <script>
        alert('Delete Success!');
        document.location.href = 'dummy.php';
        </script>
    ";
} else {
    echo "
        <script>
        alert('Delete Failed!');
        document.location.href = 'dummy.php';
        </script>
    ";
}