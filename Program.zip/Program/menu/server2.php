<?php
session_start();
require '..\function.php';

$kominfo = query("SELECT * FROM data_kominfo");

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <meta http-equiv="x-ua-compatible" content="ie=edge" />
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css" />
  <!-- Google Fonts Roboto -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" />
  <!-- MDB -->
  <link rel="stylesheet" href="css/mdb.min.css" />
  <!-- Custom styles -->
  <link rel="stylesheet" href="css/admin.css" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.min.js" integrity="sha512-d9xgZrVZpmmQlfonhQUvTR7lMPtO7NkZMkA0ABN3PHCbKA5nqylQ/yWlFAyY6hYgdF1Qh6nYiuADWwKB4C2WSw=="
    crossorigin="anonymous"></script>
</head>

<table class="table table-hover text-nowrap">
  <thead>
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Client Name</th>
      <th scope="col">Subservice</th>
      <th scope="col">Frequency</th>
      <th scope="col">Frequency Number</th>
      <th scope="col">ERP</th>
      <th scope="col">Power</th>
      <th scope="col">Gain</th>
      <th scope="col">Loss</th>
      <th scope="col">Bandwidth</th>
      <th scope="col">Polarisator</th>
      <th scope="col">Antenna Height</th>
      <th scope="col">Station Name</th>
      <th scope="col">Station Address</th>
      <th scope="col">Longitude</th>
      <th scope="col">Latitude</th>
      <th scope="col">District</th>
      <th scope="col">City</th>
    </tr>
  </thead>
  <tbody>
    <?php $i = 1; ?>
    <?php foreach($kominfo as $row):?>
    <tr>
        <td><?= $row["id"];?></th>
        <td><?= $row["CLNT_NAME"];?></td>
        <td><?= $row["SUBSERVICE"];?> Hz</td>
        <td><?= $row["FREQ"];?></td>
        <td><?= $row["Frek No"];?></td>
        <td><?= $row["ERP (dBm)"];?></td>
        <td><?= $row["Power (Watt)"];?></td>
        <td><?= $row["GAIN"];?></td>
        <td><?= $row["LOSS"];?></td>
        <td><?= $row["BWIDTH"];?></td>
        <td><?= $row["Polarisation"];?></td>
        <td><?= $row["Antenna Height"];?></td>
        <td><?= $row["STN_NAME"];?></td>
        <td><?= $row["STN_ADDR"];?></td>
        <td><?= $row["SID_LONG"];?></td>
        <td><?= $row["SID_LAT"];?></td>
        <td><?= $row["DISTRICT"];?></td>
        <td><?= $row["CITY"];?></td>
      </tr>
    <?php $i++; ?>
    <?php endforeach; ?>
  </tbody>
</table>

  <!-- MDB -->
  <script type="text/javascript" src="js/mdb.min.js"></script>
  <!-- Custom scripts -->
  <script type="text/javascript" src="js/admin.js"></script>

</body>

</html>